<?php
include("RsaSignHelp.php");//引入一个加密加签的类
class GetAccess 
{
	
	public function getAccess(){
		$sign_help = new RsaSignHelp();
        $biz_content = [];
        //渠道信息
        $biz_content['channel_code'] = 'BD';//渠道的唯一标识
        //用户信息
        $biz_content['channel_user_name'] = '王石磊';//用户姓名
        $biz_content['channel_user_code'] = '410881199406056514';//用户号码
        $biz_content['channel_user_phone'] = '18732399013';//用户手机
        $data = $sign_help->tySign($biz_content);  
        $ch = curl_init();//初始化curl
        $url = 'http://ty.laravel.com/channelsapi/get_access';
        //设置选项
        curl_setopt($ch,CURLOPT_URL,$url);//路径
        curl_setopt($ch,CURLOPT_POST,true);//post方式提交
        curl_setopt($ch,CURLOPT_POSTFIELDS,$data);//设置提交数据
        curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);//设置返回获取的输出为文本流
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);//连接超时,3秒未连接上，直接退出
        curl_setopt($ch,CURLOPT_TIMEOUT, 20);//接收数据时超时设置,如果20秒内数据未接收完，直接退出
        curl_setopt($ch,CURLOPT_HEADER,0);
            //执行选项
        $response = curl_exec($ch);
        $res = json_decode($response,true);
  		$status = $res['status'];//返回状态码，根据状态码判断接口状态
    	if($status=='200'){
    			$content = $res['content'];//返回数据
    			$access_token = $content['access_token'];//访问令牌，有身份信息和时间有效期
    			return $access_token;
    	}
	}
}
		
