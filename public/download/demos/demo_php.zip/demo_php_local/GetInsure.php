<?php
		/*投保测试DEMO*/
// 徐亚宁  341022199008240075   18610217300   广发卡号 6214623721001364792

        include("GetAccess.php");
        $get_access = new GetAccess();
        $access_token = $get_access->getAccess();
        $biz_content = [];
        $biz_content['channel_back_url'] = '回调地址';//接口回调地址（用来做异步消息回复）
        //产品信息
        $biz_content['p_code'] = '149559395942738681';//产品标识
        $biz_content['is_insure'] = 'on';//投保按钮(on/off)（默认为on）
        $biz_content['operate_code'] = '1';//（1:投保,2:查看投保信息（保单管理）,3:保全,4:查看保全信息,5:理赔,6:查看理赔信息,7:;8:,）
        //用户信息
        $biz_content['channel_user_name'] = '王石磊';//用户姓名
        $biz_content['channel_user_code'] = '410881199406056514';//用户号码
        $biz_content['channel_user_phone'] = '18732399013';//用户手机
        $biz_content['channel_user_email'] = 'wangsl@inschos.com';//用户邮箱
        $biz_content['channel_user_address'] = '北京市东城区夕照寺中街14号';//（选填）
        //银行信息
        $biz_content['channel_bank_name'] = '广发银行';//银行名称
        $biz_content['channel_bank_address'] = '北京市东城区广渠路支行';//开户行
        $biz_content['channel_bank_code'] = '6214623721001364792';//银行卡号
        $biz_content['channel_bank_phone'] = '18610217300';//银行预留手机号
        
        $sign_help = new RsaSignHelp();
        $data = $sign_help->tySign($biz_content);  
        $ch = curl_init();//初始化curl
        $url = 'http://ty.laravel.com/channelsapi/get_insure/'.$access_token;
        //设置选项
        curl_setopt($ch,CURLOPT_URL,$url);//路径
        curl_setopt($ch,CURLOPT_POST,true);//post方式提交
        curl_setopt($ch,CURLOPT_POSTFIELDS,$data);//设置提交数据
        curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);//设置返回获取的输出为文本流
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);//连接超时,3秒未连接上，直接退出
        curl_setopt($ch,CURLOPT_TIMEOUT, 20);//接收数据时超时设置,如果20秒内数据未接收完，直接退出
        curl_setopt($ch,CURLOPT_HEADER,0);
        $response = curl_exec($ch); //执行选项
        var_dump($response);
        exit;
        $res = json_decode($response,true);
  		$status = $res['status'];//返回状态码，根据状态码判断接口状态
    	if($status=='200'){//账号绑定成功
            
            if($biz_content['operate_code']=='1'){
                //投保
                $login_url = $res['content']['login_url'];
                header( "Location: $login_url" ); 
            }elseif($biz_content['operate_code']=='2'){
                //查看投保
                $login_url = $res['content']['login_url'];
                header( "Location: $login_url" ); 
            }elseif($biz_content['operate_code']=='3'){
                //理赔
                $login_url = $res['content']['login_url'];
                header( "Location: $login_url" ); 
            }elseif($biz_content['operate_code']=='4'){
                //查看理赔
                $login_url = $res['content']['login_url'];
                header( "Location: $login_url" ); 
            }elseif($biz_content['operate_code']=='5'){
                //保全
                $login_url = $res['content']['login_url'];
                header( "Location: $login_url" ); 
            }elseif($biz_content['operate_code']=='6'){
                //查看保全
                $login_url = $res['content']['login_url'];
                header( "Location: $login_url" ); 
            }
            
    	}else{
            
           echo '<h2><font color="red" style="position:absolute;top:350px;left:750px">登录失败，请重新尝试！</font></h2>';
        }
		


