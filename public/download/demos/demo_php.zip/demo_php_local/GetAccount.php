<?php

		$data = ['channel_code'=>'BD'];
        $get_account_url = 'http://ty.laravel.com/channelsapi/get_account';//接口访问地址
        $ch = curl_init();//初始化curl
        //设置选项
        curl_setopt($ch,CURLOPT_URL,$get_account_url);//路径
        curl_setopt($ch,CURLOPT_POST,true);//post方式提交
        curl_setopt($ch,CURLOPT_POSTFIELDS,$data);//设置提交数据
        curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);//设置返回获取的输出为文本流
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,3);//连接超时,3秒未连接上，直接退出
        curl_setopt($ch,CURLOPT_TIMEOUT, 20);//接收数据时超时设置,如果20秒内数据未接收完，直接退出
        curl_setopt($ch,CURLOPT_HEADER,0);
            //执行选项
        $response = curl_exec($ch);
        // var_dump($response);
        // exit;
        $res = json_decode($response,true);
  		  $status = $res['status'];//返回状态码，根据状态码判断接口状态
  		  if($status=='200'){//账号绑定成功
  			 if(isset($res['content'])){
            $content = $res['content'];
 			      echo '<h2 style="position:absolute;top:300px;left:650px"><font color="green">'.$content['account'].'授权获取成功！Congratulations!<br/>account_id:'.$content['account_id'].'<br/>'.'sign_key:'.$content['sign_key'].'<br/>API_URL:http://dev312.inschos.com/channelsapi/get_access</font><br/><a href="http://ty.laravel.com/download/demos/demo_php.zip">官方Demo下载</a><br/><a href="http://ty.laravel.com/download/files/files.zip">对接文档下载</a><br/><h2>';
  			}
  		}else{
          echo '<h2><font color="red" style="position:absolute;top:300px;left:650px">'.$res['content'].'</font></h2>';
      }
       
